using Godot;
using System;

public partial class Diamond : Area2D
{

	public static int contaDiamante = 3;
	
	public void OnBodyEntered(Node2D body){
		if(body is CharacterBody2D){
			QueueFree();
			contaDiamante--;
			GD.Print(contaDiamante);
		}
		if(contaDiamante == 0){
			GD.Print("A fase acabou");
		}	
	}

}

