using Godot;
using System;

public partial class Jogador : Godot.CharacterBody2D
{
	private Vector2 velocity;
	private Vector2 direction,direction2;
	public const float Speed = 300.0f;
	public const float Airspeed = 150.0f;
	public const float JumpVelocity = -400.0f;
	private int contapulos = 0;

	public Vector2 savePoint =new Vector2(-150,70);

	

	// Get the gravity from the project settings to be synced with RigidBody nodes.
	public float gravity = ProjectSettings.GetSetting("physics/2d/default_gravity").AsSingle();

	private AnimatedSprite2D animated;

	public override void _Ready(){
		animated = GetNode<AnimatedSprite2D>("AnimatedSprite2D");
	}//fim do ready

	public override void _PhysicsProcess(double delta)
	{
		velocity = Velocity;
		
		

		// Add the gravity.
		if (!IsOnFloor())
			velocity.Y += gravity * (float)delta;

		// Handle  Double Jump.
		if (Input.IsActionJustPressed("ui_accept") && contapulos<1){
			velocity.Y = JumpVelocity;
			contapulos++;

		}
		if (Input.IsActionJustReleased("ui_accept")){
			velocity.Y = 150;

		}
		if(IsOnFloor()){
			contapulos = 0;
		}

		// Get the input direction and handle the movement/deceleration.
		// As good practice, you should replace UI actions with custom gameplay actions.
		direction = Input.GetVector("ui_left", "ui_right", "ui_up", "ui_down");
		direction2 = Input.GetVector("esquerda", "direita", "cima", "baixo");
		if (direction != Vector2.Zero)
		{
			if(!IsOnFloor()){
				velocity.X = direction.X * Airspeed;

			}
			else{
			velocity.X = direction.X * Speed;
			}

		}
		else if(direction2 != Vector2.Zero)
		{
			if(!IsOnFloor()){
				velocity.X = direction.X * Airspeed;

			}
			else{
			velocity.X = direction.X * Speed;
			}
		}
		else
		{
			velocity.X = Mathf.MoveToward(Velocity.X, 0, Speed);
		}
		

		Velocity = velocity;
		MoveAndSlide();

		Animation(velocity);

		if(GlobalPosition.Y>500){
			GlobalPosition = savePoint;
		}

		
	} // fim process

	private void Animation(Vector2 velocity){
		//if(!IsOnFloor()){
			//animated.Play("jump");
		//}
		//else{
			if(velocity.X !=0){
				animated.Play("run");
			}else{
				animated.Stop();
			}
			if(velocity.X >0){
				animated.FlipH=true;
			}else if(velocity.X<0){
				animated.FlipH=false;
			}
		//}
	}

	public void ReturnToSavePoint(){
		GlobalPosition = savePoint;
	}
} //fim da classe
