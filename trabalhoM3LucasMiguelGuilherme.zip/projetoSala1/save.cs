using Godot;
using System;

public partial class save : CollisionShape2D
{
	public void OnBodyEntered(Node2D body){
		if(body is CharacterBody2D){
			//body.GlobalPosition = new Vector2(-88,267);
			((Jogador)body).savePoint = new Vector2(225,100);
		}
	}
}
